This folder contains additional "external" libraries that this project
depends upon.  In some cases these are published, third-party
extension libraries.  In other cases, these are private libraries
created by the project's author, to share common code with the
author's other projects.

In any case, these libraries aren't directly part of the project -
they were designed as separate packages.  For your convenience,
though, they're bundled here, so that this source package contains
everything needed to compile the project.  You'll still need to
install these libraries by "unzipping" each of these ZIP files:

    Contrib.zip

You must decide *where* to unzip these files.  You have two main
options:

1. The easiest way is simply to unzip all of these into the same
folder as the rest of the project's source code.  This will put a
private copy of each library into the project folder.

2. If you use other third-party extension libraries, you can unzip
these files into the same folder tree where you keep your other
extensions.  This will allow you to share these extensions with other
projects.

If you choose option 2, you might find that you already have one or
more of the third-party extensions already installed.  In this case,
you can skip unzipping the duplicated library or libraries.  Note that
you might want to check versions to make sure that your previously
installed version is at least as recent as the version bundled with
the project.
